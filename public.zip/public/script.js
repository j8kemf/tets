
let cart = [];

function addToCart(productName, price) {
    const product = { name: productName, price: price };
    cart.push(product);
    alert(`${productName} has been added to your cart!`);
    displayCartItems();
}

function toggleCart() {
    const cartSection = document.getElementById("cart");
    cartSection.style.display = cartSection.style.display === 'none' || cartSection.style.display === '' ? 'block' : 'none';
    displayCartItems();
}

function displayCartItems() {
    const cartItemsDiv = document.getElementById("cartItems");
    const cartTotalP = document.getElementById("cartTotal");

    cartItemsDiv.innerHTML = '';

    if (cart.length === 0) {
        cartItemsDiv.innerHTML = '<p>Your cart is empty.</p>';
    } else {
        let total = 0;
        cart.forEach(item => {
            const itemDiv = document.createElement("div");
            itemDiv.classList.add("cart-item");
            itemDiv.innerHTML = `<span>${item.name}</span><span>$${item.price.toFixed(2)}</span>`;
            cartItemsDiv.appendChild(itemDiv);
            total += item.price;
        });
        cartTotalP.innerText = `Total: $${total.toFixed(2)}`;
    }
}

function toggleChatbot() {
    const chatbot = document.getElementById("chatbot");
    chatbot.style.display = chatbot.style.display === 'none' || chatbot.style.display === '' ? 'block' : 'none';
}

function handleChatbotInput() {
    const inputField = document.getElementById("chatbotInput");
    const message = inputField.value.trim();

    if (message) {
        addMessage("user", message);
        inputField.value = '';

        fetch('/.netlify/chat', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ message })
        })
            .then(response => {
                if (!response.ok) {
                    throw new Error(`HTTP error! status: ${response.status}`);
                }
                return response.json();
            })
            .then(data => {
                if (data.reply) {
                    addMessage("bot", data.reply);
                } else if (data.error) {
                    addMessage("bot", `Error: ${data.error}`);
                } else {
                    addMessage("bot", "Sorry, I couldn't process that.");
                }
            })
            .catch(error => {
                addMessage("bot", `Error occurred: ${error.message}`);
                console.error("Chatbot fetch error:", error);
            });
    }
}

function addMessage(sender, text) {
    const messagesDiv = document.getElementById("chatbotMessages");
    const messageDiv = document.createElement("div");
    messageDiv.className = `message ${sender}`;
    messageDiv.textContent = text;
    messagesDiv.appendChild(messageDiv);
    messagesDiv.scrollTop = messagesDiv.scrollHeight;
}
